# Daily Note
Date: {{YYYY-MM-DD}}

Morning Intention:
Energy (1–10):
Primary Module: Deep Work / Father–Son Lab / Health / Learning

## Tasks / Quests
- [ ] Main
- [ ] Side
- [ ] Daily

## Reflection
- What worked today?
- What feedback loop strengthened?
- What did I teach/learn with my son?
- Insight of the day:
