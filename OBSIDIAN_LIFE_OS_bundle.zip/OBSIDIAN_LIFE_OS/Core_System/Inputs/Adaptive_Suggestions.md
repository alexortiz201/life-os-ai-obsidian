# Adaptive Suggestions
Scratchpad for new weekly inputs (articles, videos, ideas).
Later, move selected items into Curated_List with tags.
