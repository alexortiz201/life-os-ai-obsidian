# Curated Inputs
Add links grouped by tag (e.g., #Wealth, #Health, #Love, #Evolution).
Rotate weekly during your Evolution Sync.
