# Training Log
- Mon: Weights + bodyweight
- Thu: Soccer 8–9:30 pm
- Sun: Soccer 7:30–9 am (returning post-Achilles)
Notes & Adjustments:
