# Soccer Schedule
- Thu 8–9:30 pm
- Sun 7:30–9 am
