# Front-End Systems — Mastery Track
Goals: scalable UI architecture, design systems, performance, DX

Current Projects:
- [ ] Component library (tokens, theming, docs)
- [ ] Performance budget & profiling
- [ ] Accessibility sweeps (WCAG)
