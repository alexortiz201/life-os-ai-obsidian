# Robotics — Mastery Track (Future)
Goals: integrate software + hardware, control systems, sensors

Seed Ideas:
- [ ] Remote control prototype
- [ ] MCP-like control protocol
- [ ] Voice interface bridge
