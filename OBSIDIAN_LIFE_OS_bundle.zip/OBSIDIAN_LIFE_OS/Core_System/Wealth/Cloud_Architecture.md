# Cloud & Scale — Mastery Track
Goals: deployments, reliability, observability, distributed patterns

Active Loop:
- [ ] Ship a small service with autoscale
- [ ] Add tracing & alerts
- [ ] Postmortem on a chaos test
