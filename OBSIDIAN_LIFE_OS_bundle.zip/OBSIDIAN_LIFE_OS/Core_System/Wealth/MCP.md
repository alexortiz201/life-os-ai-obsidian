# MCP — Mastery Track
Goals: protocol mastery, server & UI, contribution

Active Loop:
- [ ] Build personal MCP server
- [ ] Implement UI negotiation flow
- [ ] Draft tutorial or PR
