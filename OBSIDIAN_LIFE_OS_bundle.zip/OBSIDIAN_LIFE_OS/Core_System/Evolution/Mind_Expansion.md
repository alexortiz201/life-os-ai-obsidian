# Mind Expansion
Books / videos / mentors that expanded perspective.
