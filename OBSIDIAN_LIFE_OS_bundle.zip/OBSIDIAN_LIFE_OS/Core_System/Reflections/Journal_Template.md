# Nightly Journal
- Health: what went right?
- Wealth: what progressed?
- Love: moments of connection?
- Evolution: pattern spotted?
- Affirmation: I do not chase; everything I want chases me.
