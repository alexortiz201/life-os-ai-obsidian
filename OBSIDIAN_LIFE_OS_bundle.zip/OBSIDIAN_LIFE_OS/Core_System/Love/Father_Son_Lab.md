# Father–Son Lab
Frequency: 1–2x per week
Structure: Theme → Build → Reflect → Story

Ideas:
- Voice bot demo
- Scratch or Minecraft mod
- Balloon car / line-following robot

Reflection prompts:
- What did we make?
- What would make it cooler?
