# Color Palette (suggested tokens)
primary: #7aa2f7
accent: #9ece6a
danger: #f7768e
warning: #e0af68
surface: #1a1b26
text: #c0caf5
