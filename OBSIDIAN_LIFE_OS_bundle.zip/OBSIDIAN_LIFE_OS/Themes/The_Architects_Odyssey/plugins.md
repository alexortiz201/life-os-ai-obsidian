# Active Plugins (suggested)
- Dataview
- Tracker
- Templater
- Kanban (optional)
- Style Settings / CSS snippets (optional)
