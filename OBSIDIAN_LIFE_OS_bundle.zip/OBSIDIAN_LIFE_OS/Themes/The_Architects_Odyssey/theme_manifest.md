# Theme Manifest — The Architect's Odyssey
Tone: grounded mythic (anime × FF-inspired logbook)
