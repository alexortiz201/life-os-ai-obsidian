# Iconography
Wealth: 💰 / Build
Love: ❤️ / Hearth
Health: ⚽ / Shield
Evolution: 🔮 / Cosmos
