---
arc_name: ""
phase: "Apprentice"
victory_condition: ""
type: "Wealth"  # Wealth | Love | Health | Evolution
---

# <% tp.file.title %> — Arc

**Phase:** <% tp.frontmatter.phase %>  
**Current Quest:**  
**Victory Condition:** <% tp.frontmatter.victory_condition %>

## Notes
-

## Links
- Parent Realm: <% tp.frontmatter.type %>
- Related Quests:
