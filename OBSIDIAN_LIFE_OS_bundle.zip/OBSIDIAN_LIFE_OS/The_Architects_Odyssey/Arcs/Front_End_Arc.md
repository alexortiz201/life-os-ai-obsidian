# Front-End Arc — The Flowwright
Phase: Initiation → Training
Current Quest: Build design system tokens & docs
Victory Condition: Reusable component library shipped
