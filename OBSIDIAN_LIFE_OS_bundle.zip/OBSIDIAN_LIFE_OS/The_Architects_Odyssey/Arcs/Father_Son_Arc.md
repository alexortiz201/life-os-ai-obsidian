# Father–Son Arc — The Hearthfire
Phase: Craftsman
Current Quest: Weekly Lab sessions (1–2x)
Victory Condition: Shared project demo + story
