# Recovery Arc — The Patient Warrior
Phase: Trial
Current Quest: Achilles rehab + graded return to play
Victory Condition: Pain-free soccer sessions
