# MCP Arc — Keeper of Protocols
Phase: Training → Trial
Current Quest: Implement UI negotiation & server endpoints
Victory Condition: Deployed server + tutorial/PR
