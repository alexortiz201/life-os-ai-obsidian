# The Architect — Character Sheet

## Attributes
| Stat | Value |
|:--|:--|
| INT | 14 |
| STR | 12 |
| DEX | 15 |
| CHA | 13 |
| WIS | 11 |
| LCK | 10 |

## Active Realms & Arcs
- Wealth: MCP Arc
- Love: Father–Son Arc
- Health: Recovery Arc
- Evolution: Integration Arc

## XP Log (sample)
| Date | Action | XP | Loot |
|:--|:--|:--|:--|
| 2025-10-18 | Completed MCP module | +15 | Code Relic |


---
## Dataview — Recent Quest Notes
```dataview
LIST FROM "The_Architects_Odyssey/Quests"
SORT file.mtime DESC
LIMIT 5
```
