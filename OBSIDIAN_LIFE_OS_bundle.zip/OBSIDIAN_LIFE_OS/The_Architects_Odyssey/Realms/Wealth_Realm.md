# Wealth Realm — The Forge
Arcs: Front-End, MCP, Cloud, Robotics.


---
## Arcs in this Realm (Dataview)
```dataview
LIST FROM "The_Architects_Odyssey/Arcs"
WHERE contains(file.name, this.file.name.split("_")[0]) = false
```
