# Love Realm — The Hearth
Arcs: Father–Son, Connection.


---
## Arcs in this Realm (Dataview)
```dataview
LIST FROM "The_Architects_Odyssey/Arcs"
WHERE contains(file.name, this.file.name.split("_")[0]) = false
```
