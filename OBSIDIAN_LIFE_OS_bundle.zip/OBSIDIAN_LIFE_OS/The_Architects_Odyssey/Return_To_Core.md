# Return to Core System → [[../Core_System/Weekly_Dashboard|Weekly Dashboard]]
