- Build & launch MCP server
- Create Front-End component library


---
## Dataview — All Quest Lists
```dataview
TABLE file.name AS File, file.mtime
FROM "The_Architects_Odyssey/Quests"
SORT file.mtime DESC
```
