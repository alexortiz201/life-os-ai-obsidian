# Expansion — The Architect's Odyssey
This folder declares how the theme maps onto the Core + Lore system.
